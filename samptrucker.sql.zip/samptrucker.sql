-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny9
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Май 12 2012 г., 21:12
-- Версия сервера: 5.0.51
-- Версия PHP: 5.2.6-1+lenny13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `samptrucker`
--

-- --------------------------------------------------------

--
-- Структура таблицы `atm`
--

CREATE TABLE IF NOT EXISTS `atm` (
  `id` int(11) NOT NULL,
  `atmX` float NOT NULL,
  `atmY` float NOT NULL,
  `atmZ` float NOT NULL,
  `atmRot` float NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `id` int(11) NOT NULL,
  `companyOwner` varchar(64) NOT NULL,
  `companyName` varchar(24) character set utf8 NOT NULL,
  `companyOfficeID` int(11) NOT NULL default '-1',
  `companyBank` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `deliverys`
--

CREATE TABLE IF NOT EXISTS `deliverys` (
  `id` int(11) NOT NULL,
  `deliveryProd` varchar(32) character set utf8 NOT NULL,
  `deliveryStartProp` int(11) NOT NULL,
  `deliveryEndProp` int(11) NOT NULL,
  `deliveryFragility` int(11) NOT NULL,
  `deliveryPrice` int(11) NOT NULL,
  `deliveryTrailer` int(11) NOT NULL,
  `deliveryValue` float NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `foods`
--

CREATE TABLE IF NOT EXISTS `foods` (
  `id` int(11) NOT NULL,
  `foodName` varchar(64) character set utf8 NOT NULL,
  `foodEnX` float NOT NULL,
  `foodEnY` float NOT NULL,
  `foodEnZ` float NOT NULL,
  `foodInt` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `gas`
--

CREATE TABLE IF NOT EXISTS `gas` (
  `id` int(11) NOT NULL,
  `gasX` float NOT NULL,
  `gasY` float NOT NULL,
  `gasZ` float NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `holels`
--

CREATE TABLE IF NOT EXISTS `holels` (
  `id` int(11) NOT NULL,
  `hotelPrice` int(11) NOT NULL,
  `hotelEnX` float NOT NULL,
  `hotelEnY` float NOT NULL,
  `hotelEnZ` float NOT NULL,
  `hotelInt` int(11) NOT NULL,
  `hotelName` varchar(64) character set utf8 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `magazines`
--

CREATE TABLE IF NOT EXISTS `magazines` (
  `id` int(11) NOT NULL,
  `magazineName` varchar(64) character set utf8 NOT NULL,
  `magazineX` float NOT NULL,
  `magazineY` float NOT NULL,
  `magazineZ` float NOT NULL,
  `magazineInt` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `mobilestations`
--

CREATE TABLE IF NOT EXISTS `mobilestations` (
  `id` int(11) NOT NULL,
  `mobilestationX` float NOT NULL,
  `mobilestationY` float NOT NULL,
  `mobilestationZ` float NOT NULL,
  `mobilestationRad` float NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `note`
--

CREATE TABLE IF NOT EXISTS `note` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(24) NOT NULL,
  `time` varchar(64) NOT NULL,
  `message` varchar(128) character set utf8 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

-- --------------------------------------------------------

--
-- Структура таблицы `office`
--

CREATE TABLE IF NOT EXISTS `office` (
  `id` int(11) NOT NULL,
  `officeName` varchar(64) character set utf8 NOT NULL default 'none',
  `officeOwned` int(11) NOT NULL default '0',
  `officeOwner` varchar(24) NOT NULL default 'none',
  `officeCompany` int(11) NOT NULL default '-1',
  `officeX` float NOT NULL,
  `officeY` float NOT NULL,
  `officeZ` float NOT NULL,
  `officeInt` int(11) NOT NULL,
  `officeLocked` int(11) NOT NULL default '0',
  `officePrice` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `players`
--

CREATE TABLE IF NOT EXISTS `players` (
  `id` int(11) NOT NULL auto_increment,
  `Name` varchar(24) NOT NULL,
  `Pass` varchar(64) NOT NULL,
  `online` int(11) NOT NULL default '0',
  `pAdmin` int(11) NOT NULL default '0',
  `pMoney` int(11) NOT NULL default '0',
  `pPoints` int(11) NOT NULL default '0',
  `pPhone` int(11) NOT NULL default '0',
  `pHelper` int(11) NOT NULL default '0',
  `pMutedTime` int(11) NOT NULL default '0',
  `pSex` int(11) NOT NULL default '1',
  `pJailTime` int(11) NOT NULL default '0',
  `pCarModel` int(11) NOT NULL default '0',
  `pCarColor1` int(11) NOT NULL default '0',
  `pCarColor2` int(11) NOT NULL default '0',
  `pCarMileage` float NOT NULL default '0',
  `pCarX` float NOT NULL default '0',
  `pCarY` float NOT NULL default '0',
  `pCarZ` float NOT NULL default '0',
  `pCarRot` float NOT NULL default '0',
  `pSpeedoX` int(11) NOT NULL default '498',
  `pSpeedoY` int(11) NOT NULL default '99',
  `pTutorial` int(11) NOT NULL default '0',
  `pTruckStop` int(11) NOT NULL default '0',
  `pHunger` float NOT NULL default '0',
  `pFatigue` float NOT NULL default '0',
  `pBan` int(11) NOT NULL default '0',
  `pModel` int(11) NOT NULL default '0',
  `pCarGas` float NOT NULL default '100',
  `pCarDamagePanels` int(11) NOT NULL,
  `pCarDamageDoors` int(11) NOT NULL,
  `pCarDamageLights` int(11) NOT NULL,
  `pCarDamageTires` int(11) NOT NULL,
  `pCarOilFilter` float NOT NULL default '0',
  `pCarAirFilter` float NOT NULL default '0',
  `pCarBattary` float NOT NULL default '0',
  `pCarOil` float NOT NULL default '0',
  `pCarGaskets` float NOT NULL default '0',
  `pCarSpark` float NOT NULL default '0',
  `pCarHP` float NOT NULL default '1000',
  `pCarFullHealth` int(11) NOT NULL default '1000',
  `pCarRadarDetector` int(11) NOT NULL default '0',
  `pCarFuelTank` int(11) NOT NULL default '0',
  `pCarRadio` int(11) NOT NULL default '0',
  `pCarAdditive` int(11) NOT NULL default '0',
  `pCompany` int(11) NOT NULL default '-1',
  `pCompanyTime` int(11) NOT NULL default '0',
  `pCarNeck` int(11) NOT NULL default '0',
  `pAccepted` int(11) NOT NULL default '0',
  `pCarDamper` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=438 ;

-- --------------------------------------------------------

--
-- Структура таблицы `props`
--

CREATE TABLE IF NOT EXISTS `props` (
  `id` int(11) NOT NULL,
  `propName` varchar(64) character set utf8 NOT NULL,
  `propX` float NOT NULL,
  `propY` float NOT NULL,
  `propZ` float NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `radars`
--

CREATE TABLE IF NOT EXISTS `radars` (
  `id` int(11) NOT NULL,
  `radarObjX` float NOT NULL default '0',
  `radarObjY` float NOT NULL default '0',
  `radarObjZ` float NOT NULL default '0',
  `radarObjRot` float NOT NULL default '0',
  `radarZoneX` float NOT NULL default '0',
  `radarZoneY` float NOT NULL default '0',
  `radarZoneZ` float NOT NULL default '0',
  `radarZoneRad` float NOT NULL default '0',
  `radarMaxSpeed` float NOT NULL default '90',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `regs`
--

CREATE TABLE IF NOT EXISTS `regs` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(24) character set utf8 NOT NULL,
  `strtext0` varchar(255) character set utf8 NOT NULL,
  `strtext1` varchar(255) character set utf8 NOT NULL,
  `strtext2` varchar(255) character set utf8 NOT NULL,
  `strtext3` varchar(255) character set utf8 NOT NULL,
  `strtext4` varchar(255) character set utf8 NOT NULL,
  `strtext5` varchar(255) character set utf8 NOT NULL,
  `strtext6` varchar(255) character set utf8 NOT NULL,
  `strtext7` varchar(255) character set utf8 NOT NULL,
  `strtext8` varchar(255) character set utf8 NOT NULL,
  `strtext9` varchar(255) character set utf8 NOT NULL,
  `strtext10` varchar(255) character set utf8 NOT NULL,
  `strtext11` varchar(255) character set utf8 NOT NULL,
  `strtext12` varchar(255) character set utf8 NOT NULL,
  `strtext13` varchar(255) character set utf8 NOT NULL,
  `strtext14` varchar(255) character set utf8 NOT NULL,
  `strtext15` varchar(255) character set utf8 NOT NULL,
  `strtext16` varchar(255) character set utf8 NOT NULL,
  `strtext17` varchar(255) character set utf8 NOT NULL,
  `strtext18` varchar(255) character set utf8 NOT NULL,
  `strtext19` varchar(255) character set utf8 NOT NULL,
  `strtext20` varchar(255) character set utf8 NOT NULL,
  `strtext21` varchar(255) character set utf8 NOT NULL,
  `strtext22` varchar(255) character set utf8 NOT NULL,
  `strtext23` varchar(255) character set utf8 NOT NULL,
  `strtext24` varchar(255) character set utf8 NOT NULL,
  `checked` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=493 ;

-- --------------------------------------------------------

--
-- Структура таблицы `repairs`
--

CREATE TABLE IF NOT EXISTS `repairs` (
  `id` int(11) NOT NULL,
  `repairX` float NOT NULL,
  `repairY` float NOT NULL,
  `repairZ` float NOT NULL,
  `repairName` varchar(64) character set utf8 NOT NULL,
  `repairLabelX` float NOT NULL,
  `repairLabelY` float NOT NULL,
  `repairLabelZ` float NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `roadworks`
--

CREATE TABLE IF NOT EXISTS `roadworks` (
  `id` int(11) NOT NULL,
  `roadworkName` varchar(255) character set utf8 NOT NULL,
  `roadworkFileID` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `trailers`
--

CREATE TABLE IF NOT EXISTS `trailers` (
  `id` int(11) NOT NULL,
  `tiModel` int(11) NOT NULL,
  `tiX` float NOT NULL,
  `tiY` float NOT NULL,
  `tiZ` float NOT NULL,
  `tiRot` float NOT NULL,
  `tiColor1` int(11) NOT NULL,
  `tiColor2` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `truckstops`
--

CREATE TABLE IF NOT EXISTS `truckstops` (
  `id` int(11) NOT NULL,
  `tsName` varchar(64) character set utf8 NOT NULL default 'none',
  `tsX` float NOT NULL default '0',
  `tsY` float NOT NULL default '0',
  `tsZ` float NOT NULL default '0',
  `tsRot` float NOT NULL default '0',
  `tsCamX` float NOT NULL default '0',
  `tsCamY` float NOT NULL default '0',
  `tsCamZ` float NOT NULL default '0',
  `tsLabelX` float NOT NULL default '0',
  `tsLabelY` float NOT NULL default '0',
  `tsLabelZ` float NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
